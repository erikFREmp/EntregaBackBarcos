package com.barcos.barco.controller;

import com.barcos.barco.entity.Amarre;
import com.barcos.barco.service.AmarreService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/barcos/amarre")
public class AmarreController {
    private final AmarreService amarreService;

    public AmarreController(AmarreService amarreService) {
        this.amarreService = amarreService;
    }
    //http://localhost:8080/barcos/amarre/create
    @PostMapping
    public Amarre save(@RequestBody Amarre amarre) {
        return amarreService.save(amarre);
    }
    @GetMapping
    public List<Amarre> findAll(){
        return amarreService.findAll();
    }
    //http://localhost:8080/barcos/barco/
    @GetMapping("/{id}")
    public Amarre findById(@PathVariable Integer id){
        return amarreService.findById(id);
    }
    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Integer id){
        amarreService.deleteById(id);
    }
    //http://localhost:8080/api/customers/
    @PutMapping
    public Amarre updateAmarre(@RequestBody Amarre amarre){
        Amarre amarreDb = amarreService.findById(amarre.getId());
        amarreDb.setCuota(amarre.getCuota());
        return amarreService.update(amarreDb);
    }
}
