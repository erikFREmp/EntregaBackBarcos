package com.barcos.barco.service;

import com.barcos.barco.entity.Amarre;
import com.barcos.barco.entity.Barco;
import com.barcos.barco.exception.ResourceFoundException;
import com.barcos.barco.repository.AmarreRepository;
import com.barcos.barco.repository.BarcoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AmarreServiceImpl implements AmarreService{
    private final AmarreRepository amarreRepository;

    public AmarreServiceImpl(AmarreRepository amarreRepository) {
        this.amarreRepository = amarreRepository;
    }

    @Override
    public Amarre save(Amarre amarre) {
        return amarreRepository.save(amarre);
    }

    @Override
    public List<Amarre> findAll() {
        return amarreRepository.findAll();
    }

    @Override
    public Amarre findById(Integer id) {
        return amarreRepository.findById(id).orElseThrow(
                ResourceFoundException::new
        );
    }

    @Override
    public void deleteById(Integer id) {
        amarreRepository.deleteById(id);
    }

    @Override
    public Amarre update(Amarre amarre) {
        return amarreRepository.save(amarre);
    }
}
