package com.barcos.barco.service;

import com.barcos.barco.entity.Salida;

import java.util.List;

public interface SalidaService {
    Salida save(Salida salida);
    List<Salida> findAll();
    Salida findById(Integer id);
    void deleteById(Integer id);
    Salida update(Salida salida);
}
