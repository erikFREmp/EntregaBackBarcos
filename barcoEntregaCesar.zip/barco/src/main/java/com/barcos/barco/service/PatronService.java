package com.barcos.barco.service;

import com.barcos.barco.entity.Patron;

import java.util.List;

public interface PatronService {
    Patron save(Patron patron);
    List<Patron> findAll();
    Patron findById(Integer id);
    void deleteById(Integer id);
    Patron update(Patron patron);

}
