package com.barcos.barco.service;
import java.util.List;
import com.barcos.barco.entity.Barco;

public interface BarcoService {
    Barco save(Barco barco);

    List<Barco> findAll();

    Barco findById(Integer id);

    void deleteById(Integer id);

    Barco update(Barco barco);

}
