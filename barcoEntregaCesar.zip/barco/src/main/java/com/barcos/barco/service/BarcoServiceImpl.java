package com.barcos.barco.service;

import com.barcos.barco.entity.Barco;
import com.barcos.barco.exception.ResourceFoundException;
import com.barcos.barco.repository.BarcoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class BarcoServiceImpl implements BarcoService {
    private final BarcoRepository barcoRepository;

    public BarcoServiceImpl(BarcoRepository barcoRepository) {
        this.barcoRepository = barcoRepository;
    }
    @Override
    public Barco save(Barco barco) {
        return barcoRepository.save(barco);
    }
    @Override
    public List<Barco> findAll() {
        return barcoRepository.findAll();
    }
    @Override
    public Barco findById(Integer id) {
        return barcoRepository.findById(id).orElseThrow(
                ResourceFoundException::new
        );
    }


    @Override
    public void deleteById(Integer id) {
        barcoRepository.deleteById(id);
    }

    @Override
    public Barco update(Barco customer) {
        return barcoRepository.save(customer);
    }

}
