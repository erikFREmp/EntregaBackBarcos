package com.barcos.barco.controller;

import com.barcos.barco.entity.Patron;
import com.barcos.barco.service.PatronService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/barcos/patron")
public class PatronController {
    private final PatronService patronService;
    public PatronController(PatronService patronService) {
        this.patronService = patronService;
    }
    @PostMapping
    public Patron save(@RequestBody Patron patron) {
        return patronService.save(patron);
    }
    @GetMapping
    public List<Patron> findAll(){
        return patronService.findAll();
    }
    @GetMapping("/{id}")
    public Patron findById(@PathVariable Integer id){
        return patronService.findById(id);
    }
    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Integer id){
        patronService.deleteById(id);
    }
    @PutMapping
    public Patron updatePatron(@RequestBody Patron patron) {
        Patron patronDb = patronService.findById(patron.getId());
        patronDb.setId(patron.getId());
        patronDb.setNombre(patron.getNombre());
        patronDb.setApellidos(patron.getApellidos());
        patronDb.setTelefono(patron.getTelefono());
        return patronService.update(patronDb);
    }

}
