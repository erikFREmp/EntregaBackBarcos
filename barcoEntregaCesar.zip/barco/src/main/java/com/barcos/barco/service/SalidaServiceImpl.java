package com.barcos.barco.service;

import com.barcos.barco.entity.Patron;
import com.barcos.barco.entity.Salida;
import com.barcos.barco.exception.ResourceFoundException;
import com.barcos.barco.repository.SalidaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SalidaServiceImpl implements SalidaService {
    private final SalidaRepository salidaRepository;
    public SalidaServiceImpl(SalidaRepository salidaRepository) {
        this.salidaRepository = salidaRepository;
    }
    @Override
    public Salida save(Salida salida) {
        return salidaRepository.save(salida);
    }

    @Override
    public List<Salida> findAll() {
        return salidaRepository.findAll();
    }

    @Override
    public Salida findById(Integer id) {
        return salidaRepository.findById(id).orElseThrow(
                ResourceFoundException::new
        );
    }

    @Override
    public void deleteById(Integer id) {
        salidaRepository.deleteById(id);
    }

    @Override
    public Salida update(Salida salida) {
        return salidaRepository.save(salida);
    }
}
