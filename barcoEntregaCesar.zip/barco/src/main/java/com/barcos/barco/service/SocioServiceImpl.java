package com.barcos.barco.service;

import com.barcos.barco.entity.Patron;
import com.barcos.barco.entity.Socio;
import com.barcos.barco.exception.ResourceFoundException;
import com.barcos.barco.repository.SocioRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SocioServiceImpl implements SocioService {
    private final SocioRepository socioRepository;
    public SocioServiceImpl(SocioRepository socioRepository) {
        this.socioRepository = socioRepository;
    }

    @Override
    public Socio save(Socio socio) {
        return socioRepository.save(socio);
    }

    @Override
    public List<Socio> findAll() {
        return socioRepository.findAll();
    }

    @Override
    public Socio findById(Integer id) {
        return socioRepository.findById(id).orElseThrow(
                ResourceFoundException::new
        );
    }

    @Override
    public void deleteById(Integer id) {
        socioRepository.deleteById(id);
    }

    @Override
    public Socio update(Socio socio) {
        return socioRepository.save(socio);
    }
}
