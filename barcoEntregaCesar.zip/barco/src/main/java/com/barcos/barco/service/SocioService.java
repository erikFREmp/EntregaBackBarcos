package com.barcos.barco.service;

import com.barcos.barco.entity.Socio;

import java.util.List;

public interface SocioService {
    Socio save (Socio socio);
    List<Socio> findAll();
    Socio findById(Integer id);
    void deleteById(Integer id);
    Socio update(Socio socio);

}
