package com.barcos.barco.controller;

import com.barcos.barco.entity.Barco;
import com.barcos.barco.service.BarcoService;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
//http://localhost:8080/barcos/barco
@RequestMapping("/barcos/barco")
public class BarcoController {
    private final BarcoService barcoService;

    public BarcoController(BarcoService barcoService) {
        this.barcoService = barcoService;
    }
    //http://localhost:8080/barcos/barco/create
    @PostMapping
    public Barco save(@RequestBody Barco barco) {
        return barcoService.save(barco);
    }
    @GetMapping
    public List<Barco> findAll(){
        return barcoService.findAll();
    }
    //http://localhost:8080/barcos/barco/
    @GetMapping("/{id}")
    public Barco findById(@PathVariable Integer id){
        return barcoService.findById(id);
    }
    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Integer id){
        barcoService.deleteById(id);
    }
    //http://localhost:8080/api/customers/
    @PutMapping
    public Barco updateBarco(@RequestBody Barco barco){
        Barco barcoDb = barcoService.findById(barco.getId());
        barcoDb.setIdSocio(barco.getIdSocio());
        barcoDb.setMatricula(barco.getMatricula());
        barcoDb.setNombre(barco.getNombre());
        barcoDb.setNumAmarre(barco.getNumAmarre());
        return barcoService.update(barcoDb);
    }
}
