package com.barcos.barco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BarcoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BarcoApplication.class, args);
	}

}
