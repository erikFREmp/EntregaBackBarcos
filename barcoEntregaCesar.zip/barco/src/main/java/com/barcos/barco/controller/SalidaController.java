package com.barcos.barco.controller;

import com.barcos.barco.entity.Patron;
import com.barcos.barco.entity.Salida;
import com.barcos.barco.service.SalidaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/barcos/salida")
public class SalidaController {
    private final SalidaService salidaService;
    public SalidaController(SalidaService salidaService) {
        this.salidaService = salidaService;
    }
    @PostMapping
    public Salida save(@RequestBody Salida salida) {
        return salidaService.save(salida);
    }
    @GetMapping
    public List<Salida> findAll(){
        return salidaService.findAll();
    }
    @GetMapping("/{id}")
    public Salida findById(@PathVariable Integer id){
        return salidaService.findById(id);
    }
    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Integer id){
        salidaService.deleteById(id);
    }
    @PutMapping
    public Salida updateSalida(@RequestBody Salida salida) {
        Salida salidaDb = salidaService.findById(salida.getIdSalida());
        salidaDb.setIdSalida(salida.getIdSalida());
        salidaDb.setIdPatron(salida.getIdPatron());
        salidaDb.setIdBarco(salida.getIdBarco());
        salidaDb.setFecha(salida.getFecha());
        salidaDb.setDestino(salida.getDestino());
        return salidaService.update(salidaDb);
    }

}
