package com.barcos.barco.entity;
import jakarta.persistence.*;
@Entity
@Table(name = "barco")
public class Barco {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    private Integer idSocio;
    private String matricula;
    private String nombre;
    @Column(unique = true, nullable = false)
    private Integer numAmarre;

    public Barco() {
    }

    public Barco(Integer id, Integer idSocio, String matricula, String nombre, Integer numAmarre) {
        this.id = id;
        this.idSocio = idSocio;
        this.matricula = matricula;
        this.nombre = nombre;
        this.numAmarre = numAmarre;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdSocio() {
        return idSocio;
    }

    public void setIdSocio(Integer idSocio) {
        this.idSocio = idSocio;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getNumAmarre() {
        return numAmarre;
    }

    public void setNumAmarre(Integer numAmarre) {
        this.numAmarre = numAmarre;
    }
}
