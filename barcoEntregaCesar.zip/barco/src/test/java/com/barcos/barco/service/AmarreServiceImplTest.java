package com.barcos.barco.service;

import com.barcos.barco.entity.Amarre;
import com.barcos.barco.repository.AmarreRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class AmarreServiceImplTest {
    // Mock del repositorio Amarre
    @Mock
    private AmarreRepository amarreRepository;
    // Inyeccion de dependencias de Mock en el service
    @InjectMocks
    private AmarreServiceImpl amarreService;
    private Amarre amarre;
    // Método de configuración previo
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Creación de un objeto amarre para los tests
        amarre = new Amarre();
        amarre.setId(1);
        amarre.setCuota(10.0);
    }
    @Test
    void save() {
        // El cuando del repositorio Mock
        when(amarreRepository.save(amarre)).thenReturn(amarre);
        // Llama al método save() del servicio
        Amarre savedAmarre = amarreService.save(amarre);
        // Verifica que el objeto devuelto por el método save() coincida con el objeto que se espera
        assertEquals(1, savedAmarre.getId());
        assertEquals(10.0, savedAmarre.getCuota());
        // Verificar que se llamo al menos una vez
        verify(amarreRepository).save(amarre);
    }

    @Test
    void findById() {
        when(amarreRepository.findById(1)).thenReturn(Optional.of(amarre));

        Amarre foundAmarre = amarreService.findById(1);

        assertEquals(1, foundAmarre.getId());
        assertEquals(10.0, foundAmarre.getCuota());
        verify(amarreRepository).findById(1);
    }

    @Test
    void deleteById() {
        // Llama al método deleteById() del servicio
        amarreService.deleteById(1);
        // Verifica que se llamo al menos una vez
        verify(amarreRepository).deleteById(1);
    }

    @Test
    void update() {
        when(amarreRepository.save(amarre)).thenReturn(amarre);

        Amarre updatedAmarre = amarreService.update(amarre);

        assertEquals(1, updatedAmarre.getId());
        assertEquals(10.0, updatedAmarre.getCuota());
        verify(amarreRepository).save(amarre);
    }

    @Test
    void findAll() {
        when(amarreRepository.findAll()).thenReturn(Arrays.asList(amarre));

        // Llama al método findAll() del servicio
        List<Amarre> amarres = amarreService.findAll();

        verify(amarreRepository).findAll();

        // También puedes verificar otros aspectos, como el tamaño de la lista devuelta
        assertEquals(1, amarres.size());
    }
}